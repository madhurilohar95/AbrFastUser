
class ChooseUsModel {
  String? icon;
  String? title;

  ChooseUsModel({required this.icon, required this.title});
}